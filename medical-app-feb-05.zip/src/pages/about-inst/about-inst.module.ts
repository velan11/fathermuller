import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AboutInstPage } from './about-inst';

@NgModule({
  declarations: [
    AboutInstPage,
  ],
  imports: [
    IonicPageModule.forChild(AboutInstPage),
  ],
})
export class AboutInstPageModule {}
