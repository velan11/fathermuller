import { NgModule } from '@angular/core';
import { SafepipePipe } from './safepipe/safepipe';
@NgModule({
	declarations: [SafepipePipe],
	imports: [],
	exports: [SafepipePipe]
})
export class PipesModule {}
